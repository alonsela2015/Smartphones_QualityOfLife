# # This code is a part of the data analysis in the Smartphone Lifequality article
# # The code inspects the different questions on the questionairs, and finds the 
# # relationships between the different features. 
# # Created by Dr. Alon Sela 24.7.2019
## corrections and modifications 10/11/2019
install.packages("Rtools")
install.packages("clmm2")
install.packages("readstata13")
install.packages("pheatmap")
install.packages("lme4")
## load package
library(pheatmap)
library(readstata13)
library(lme4)

# setwd("../data/")
a<-Sys.info()
MYPATH<-dirname(rstudioapi::getSourceEditorContext()$path)
setwd(MYPATH)
dat<-read.csv(file = "../data/results3.9 withCorrelations.csv", header = TRUE, stringsAsFactors = FALSE, )
header<-colnames(dat)
df2<-dat
# Normalize sum of "well being" factors
df2$sum<-(round(as.numeric(dat$sum) / 10))
# 
df2$sum<-ordered(df2$sum, levels = c(0,1 ,2 ,3, 4, 5, 6, 7, 8, 9))
colnames(df2) <- header

# compute spearman ranked correlation matrix for variable 1:38 vs 1:38
dt<-as.data.frame(c())
for (j in 1:38){
  a<-c()
  for (i in 1:38){
    a<-c(a,cor(as.numeric(df2[,i]), as.numeric(df2[,j]), use = "complete.obs", method="spearman"))
  }
  dt<-rbind(dt,a)
}
#change to matrix format
mat_dt<-as.matrix(dt)
# name header
colnames(mat_dt) <- c(header)
row.names(mat_dt) <- c(header)

# Normalize to Unit size in order to find a true slope in the regression
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

# First heatmap - all questions
heatmap(t(mat_dt[1:37, 1:37]), 
        labRow = rownames(mat_dt),
        labCol = header, 
        hclustfun = hclust,
        symm = TRUE, 
        margins = c(15,15),
        cexRow = 0.5,
        cexCol = 0.5)
  
# Second heatmap - Only Smartphone use vs Life Quality effect. Col-Rows -> 1:15,16:37
mat_short<-mat_dt[1:15,16:37]
mat_short_normalis<-t(normalize(mat_short))
heatmap(mat_short_normalis, 
        labRow = rownames(mat_short),
        labCol = colnames(mat_short), 
        margins = c(10, 10), 
        #symm = FALSE,  
        cexRow = 0.8, verbose = TRUE, 
        #keep.dendro = TRUE, 
           )

# Separates to two components according to the highest hierachy in the hirarchical clusteirng 
# We name these clusters, the "Latent" and the "Concious" clusters of factors.
Latent <- (df2$Do.you.use.your.smartphone.in.parallel.with.other.activities...driving..cooking...TV. +
           df2$�..How.many.smartphones.do.you..carry.. + 
           df2$Do.you.go.to.bed.with.the.smartphonephone.at.your.side. +
           df2$Do.you.use.your.smartphone.in.the.middle.of.the.night. +  
           df2$Do.you.consider.yourself.as.addicted.to.the.use.of.the.smartphone.) / 5

Concious<-(df2$Do.you.consider.the.smartphone.an.indispensable.tool.for.your.work.+
           df2$Do.you.consider.the.smartphon.an.indispensable.tool.for.your.social.life.+
           df2$Do.you.take.your.smartphone.with.you.to.the.restroom.+
           df2$How.many.social.networks..e.g..facebook..twitter..are..on.your.smartphone.+
           df2$how.many.socia.netowrks.apps +
           df2$Do.you.use.the.location.based.services.of.the.smartphone.+
           df2$For.how.long.have.you.had.a.smartphone.+
           df2$How.many.apps.you.have.in.your.smartphone.+
           df2$How.often.do.you.change.your.smartphone.+
           df2$Do.you.use.your.smartphone.camera..calculator..notes..reading.book..payments.) / 10

# binds the Latent cluster, the Concious cluster, and the Lfe Quality results into a single data frame.
reg_table<-as.data.frame(cbind(as.numeric(dat$sum), Concious, Latent, deparse.level = 1))
colnames(reg_table) <- c("LifeQuality","Concious", "Latent")
# Thre were only a few NA in the data, but these were removed. 
reg_table_clean<-na.omit(reg_table)
# histogram of life quality after normalization
reg_table_clean$LifeQuality <- normalize(reg_table_clean$LifeQuality) 
reg_table_clean$Concious<-normalize(reg_table_clean$Concious) 
reg_table_clean$Latent<-normalize(reg_table_clean$Latent)
#Create a histogram of Life_quality measure
plot.new()
hist(reg_table_clean$LifeQuality, breaks = 30, xlab = "Life_Quality (Normalized)", main = "Life Quality Distribution")
med<-median(reg_table_clean$LifeQuality)
#med<-0.4
abline(v=med, col="red", lwd=3, lty=2)
# # ################################################################
# # ######################  MODEL 1  ###############################
# simple regresson analysis of Concious and Latent factors
# finds only the latent factor is influencial
linearMod <- lm(LifeQuality ~ Concious + Latent, data=reg_table_clean)
summary(linearMod)
# # ################################################################
# # ########################  MODEL 2   ############################
LatentDF1 <- df2$Do.you.use.your.smartphone.in.parallel.with.other.activities...driving..cooking...TV.
LatentDF2 <- df2$�..How.many.smartphones.do.you..carry..
LatentDF3 <- df2$Do.you.go.to.bed.with.the.smartphonephone.at.your.side.
LatentDF4 <- df2$Do.you.use.your.smartphone.in.the.middle.of.the.night.
LatentDF5 <- df2$Do.you.consider.yourself.as.addicted.to.the.use.of.the.smartphone.

# # binds the Latent cluster, the Concious cluster, and the Lfe Quality results into a single data frame.
reg_table_latent<-as.data.frame(cbind(reg_table$LifeQuality, LatentDF1,LatentDF2,LatentDF3,LatentDF4,LatentDF5, deparse.level = 1))

#reg_table_latent<-as.data.frame(cbind(reg_table_latent$LifeQualityBoolean, LatentDF1,LatentDF2,LatentDF3,LatentDF4,LatentDF5, deparse.level = 1))
reg_table_latent<-normalize(reg_table_latent)
colnames(reg_table_latent)[1]<-"LifeQuality"
#
linearMod2 <- lm(LifeQuality ~ LatentDF1 + LatentDF2 + LatentDF3+LatentDF4 + LatentDF5, data=reg_table_latent)
summary(linearMod2)

# # ################################################################
# # ########################  MODEL 3 - All variables   ############################
df2$sum<-as.numeric(df2$sum)
linearMod3a<- lm(sum~., data=df2)
summary(linearMod3a)

# # ################################################################
# # ########################  MODEL 3 - All variables   ########################
datModel3<-cbind.data.frame(dat[1:15], dat$sum, deparse.level = 2)
scalar1 <- function(x) {x / sqrt(sum(x^2))}
datModel3Norm<-as.data.frame.array(apply(datModel3, 2, scalar1))
#a<-dat$How.many.social.networks..e.g..facebook..twitter..are..on.your.smartphone.
#m<-round(mean(na.exclude(a)), digits = 0)

#datModel3Norm<-as.data.frame.array(apply(datModel3, 2, normalize))
names(datModel3Norm)[16]<-"sum"
#datModel3Norm<-as.matrix(datModel3Norm)
linearMod3<- lm(sum~., data=datModel3Norm)
 
s<-summary(linearMod3)
a<-anova(linearMod3)
###########################################################################
s
a
###########################################################################

